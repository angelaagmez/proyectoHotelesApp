package edu.fpdual.hotelesapp.objetos;
/**
 * Enum de Tipo de Servicio
 * @author angela.bonilla.gomez
 * @author g.waack.carneado
 * @author g.moreno.rodriguez
 *
 */
public enum TipoServicio {
	HOTEL,HABITACION
}
