# appHotelesServices
servicio web actualizar y borrar Registros junto con el proyecto appHoteles
